Extension library for Minuit Class
Developed by Yehan Edirisinghe